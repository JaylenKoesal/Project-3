<?php
define('SERVERNAME', 'localhost');
define('USERNAME', 'root');
define('PASSWORD', '');
define('DATABASE', 'wings_project');
define('CRUD_TABLE', 'wings');
?>

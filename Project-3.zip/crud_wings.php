<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crud</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <?php
    // functie: Programma CRUD wings
    // auteur: WiJaylen Koesal   

    // Initialisatie
    include 'functions.php';

    // Main

    // Aanroep functie 
    crudwings();
    ?>

</body>
</html>



